package com.konark.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class MailConfig {

	@Value("${spring.mail.host:smtp.gmail.com}")
	private String host;

	@Value("${spring.mail.port:587}")
	private int port;

	@Value("${spring.mail.username:}")
	private String username;

	@Value("${spring.mail.password:}")
	private String password;

	@Value("${spring.mail.properties.mail.smtp.auth:true}")
	private String smtpAuth;

	@Value("${spring.mail.properties.mail.smtp.starttls.enable:true}")
	private String starttlsEnable;

	@Bean
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(host);
		mailSender.setPort(port);
		if (username != null && !username.trim().isEmpty()) {
			mailSender.setUsername(username);
		}
		if (password != null && !password.trim().isEmpty()) {
			mailSender.setPassword(password);
		}

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", smtpAuth);
		props.put("mail.smtp.starttls.enable", starttlsEnable);
		props.put("mail.debug", "false");

		return mailSender;
	}
}
