package com.konark.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.konark.dto.VendorInventoryProjection;
import com.konark.entity.VendorItemEntity;
import com.konark.entity.pk.VendorItemPK;

public interface VendorItemRepository extends CrudRepository<VendorItemEntity, VendorItemPK> {

	@Query(value = "SELECT * FROM SW_VendorItems v WHERE v.Vendor_Number = :vendorNumber", nativeQuery = true)
	List<VendorItemEntity> findVendorItemsByVendorNumber(@Param("vendorNumber") String vendorNumber);

	List<VendorItemEntity> findByVendorNumber(String vendorNumber);

	Iterable<VendorItemEntity> findByItemNameContainingAndVendorNumberNotIn(String itemName, List<String> vendorNumber);
	
	List<VendorItemEntity> findByVendorNumberNotIn(List<String> vendorNumber);

	@Query(value = "SELECT * FROM Inventory_Vendors invVendors WHERE invVendors.Vendor_Number NOT IN (:vendorNumber) AND invVendors.ItemNum = :itemNumber", nativeQuery = true)
	Iterable<VendorItemEntity> findByItemNumberContainingAndVendorNumberNotIn(@Param("itemNumber") String itemNumber, @Param("vendorNumber") List<String> vendorNumber);
	
	/*@Query(value = "SELECT DISTINCT vendorDept FROM SW_VendorItems v WHERE v.Vendor_Number = :vendorNumber", nativeQuery = true)
	List<String> findDistinctDepartmentsByVendorNumber(String vendorNumber);*/
	
	@Query(
		    value = "SELECT DISTINCT " +
		            "inventory.Dept_ID, " +
		            "CAST(department.Description AS NVARCHAR(255)) AS Description " +
		            "FROM Inventory_Vendors invVend " +
		            "JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum " +
		            "JOIN Departments department ON department.Dept_ID = inventory.Dept_ID " +
		            "WHERE invVend.Vendor_Number = :vendorNumber",
		    nativeQuery = true
		)
		List<Object[]> findDistinctDepartmentsByVendorNumber(@Param("vendorNumber") String vendorNumber);

	@Query(value = "SELECT invVend.ItemNum, invVend.Store_ID, " +
            "invVend.Vendor_Number, invVend.costPer, " +
            "invVend.Case_Cost, invVend.NumPerVenCase, " +
            "invVend.Vendor_Part_Num, vendor.Company, " +
            "inventory.ItemName, inventory.In_Stock, " +
            "inventory.Dept_ID, department.Description " +
            "FROM Inventory_Vendors invVend " +
            "JOIN Vendors vendor ON vendor.Vendor_Number = invVend.Vendor_Number " +
            "JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum " +
            "JOIN Departments department ON department.Dept_ID = inventory.Dept_ID",
    nativeQuery = true)
List<Object[]> findVendorInventoryDataRaw();

@Query(value = "SELECT " +
        "invVend.ItemNum, invVend.Store_ID, invVend.Vendor_Number, " +
        "invVend.costPer, invVend.Case_Cost, invVend.NumPerVenCase, " +
        "invVend.Vendor_Part_Num, vendor.Company, " +
        "inventory.ItemName, inventory.In_Stock, inventory.Dept_ID, " +
        "department.Description " +
        "FROM Inventory_Vendors invVend " +
        "JOIN Vendors vendor ON vendor.Vendor_Number = invVend.Vendor_Number " +
        "JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum " +
        "JOIN Departments department ON department.Dept_ID = inventory.Dept_ID " +
        "WHERE invVend.Store_ID = :storeId AND invVend.Vendor_Number = :vendorNumber",
nativeQuery = true)
List<Object[]> findVendorInventoryDataByStoreAndVendor(@Param("storeId") String storeId,
                                                @Param("vendorNumber") String vendorNumber);

@Query(value = "SELECT " +
        "invVend.ItemNum AS itemNum, " +
        "invVend.Store_ID AS storeId, " +
        "invVend.Vendor_Number AS vendorNumber, " +
        "invVend.costPer AS costPer, " +
        "invVend.Case_Cost AS caseCost, " +
        "invVend.NumPerVenCase AS numPerVenCase, " +
        "invVend.Vendor_Part_Num AS vendorPartNum, " +
        "vendor.Company AS company, " +
        "inventory.ItemName AS itemName, " +
        "inventory.In_Stock AS inStock, " +
        "inventory.Dept_ID AS deptId, " +
        "department.Description AS description " +
        "FROM Inventory_Vendors invVend " +
        "JOIN Vendors vendor ON vendor.Vendor_Number = invVend.Vendor_Number " +
        "JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum " +
        "JOIN Departments department ON department.Dept_ID = inventory.Dept_ID " +
        "WHERE invVend.Store_ID = :storeId AND invVend.Vendor_Number = :vendorNumber",
nativeQuery = true)
List<VendorInventoryProjection> findByStoreIdAndVendorNumber(
@Param("storeId") String storeId,
@Param("vendorNumber") String vendorNumber
);	@Query(value = "SELECT " +
		"vendor.Company AS vendorName, " +
        "invVend.ItemNum AS itemNum, " +
        "invVend.Store_ID AS storeId, " +
        "invVend.Vendor_Number AS vendorNumber, " +
        "invVend.costPer AS costPer, " +
        "invVend.Case_Cost AS caseCost, " +
        "invVend.NumPerVenCase AS numPerVenCase, " +
        "invVend.Vendor_Part_Num AS vendorPartNum, " +
        "vendor.Company AS company, " +
        "inventory.ItemName AS itemName, " +
        "inventory.In_Stock AS inStock, " +
        "inventory.Dept_ID AS deptId, " +
        "department.Description AS description " +
        "FROM Inventory_Vendors invVend " +
        "JOIN Vendors vendor ON vendor.Vendor_Number = invVend.Vendor_Number " +
        "LEFT JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum AND inventory.Store_ID = invVend.Store_ID " +
        "LEFT JOIN Departments department ON department.Dept_ID = inventory.Dept_ID " +
        "WHERE invVend.Store_ID = '9999' " +
        "AND invVend.ItemNum = :itemNumber",
    nativeQuery = true)
List<VendorInventoryProjection> findReferenceVendorItems(
@Param("itemNumber") String itemNumber
);@Query(value = "SELECT " +
		"vendor.Company AS vendorName, " +
        "invVend.ItemNum AS itemNum, " +
        "invVend.Store_ID AS storeId, " +
        "invVend.Vendor_Number AS vendorNumber, " +
        "invVend.costPer AS costPer, " +
        "invVend.Case_Cost AS caseCost, " +
        "invVend.NumPerVenCase AS numPerVenCase, " +
        "invVend.Vendor_Part_Num AS vendorPartNum, " +
        "vendor.Company AS company, " +
        "inventory.ItemName AS itemName, " +
        "inventory.In_Stock AS inStock, " +
        "inventory.Dept_ID AS deptId, " +
        "department.Description AS description " +
        "FROM Inventory_Vendors invVend " +
        "JOIN Vendors vendor ON vendor.Vendor_Number = invVend.Vendor_Number " +
        "JOIN Inventory inventory ON inventory.ItemNum = invVend.ItemNum AND inventory.Store_ID = invVend.Store_ID " +
        "JOIN Departments department ON department.Dept_ID = inventory.Dept_ID " +
        "WHERE invVend.Vendor_Number = :vendorNumber",
    nativeQuery = true)
List<VendorInventoryProjection> findItemsByVendorNumber( @Param("vendorNumber") String vendorNumber
);

	@Query(
		value = """
            WITH consolidated AS (
                SELECT
                    vendor.Company AS vendorName,
                    COALESCE(invVend.ItemNum, inv2.ItemNum, newInvVend.Vendor_Part_Num) AS itemNum,
                    COALESCE(invVend.Store_ID, :storeId) AS storeId,
                    COALESCE(invVend.Vendor_Number, newInvVend.Vendor_Number) AS vendorNumber,
                    COALESCE(
                        CASE WHEN TRY_CONVERT(decimal(19,4), invVend.costPer) = 0
                             THEN NULL ELSE invVend.costPer END,
                        newInvVend.CostPer
                    ) AS costPer,
                    COALESCE(
                        CASE WHEN TRY_CONVERT(decimal(19,4), invVend.Case_Cost) = 0
                             THEN NULL ELSE invVend.Case_Cost END,
                        newInvVend.Case_Cost
                    ) AS caseCost,
                    COALESCE(
                        CASE WHEN TRY_CONVERT(decimal(19,4), invVend.NumPerVenCase) = 0
                             THEN NULL ELSE invVend.NumPerVenCase END,
                        newInvVend.NumPerVenCase
                    ) AS numPerVenCase,
                    COALESCE(NULLIF(LTRIM(RTRIM(invVend.Vendor_Part_Num)), ''),
                             newInvVend.Vendor_Part_Num) AS vendorPartNum,
                    COALESCE(inventory.ItemName, inv2.ItemName, newInvVend.ItemName) AS itemName,
                    newInvVend.Category AS category,
                    COALESCE(inventory.In_Stock, inv2.In_Stock) AS inStock,
                    COALESCE(inventory.Dept_ID, inv2.Dept_ID) AS deptId,
                    COALESCE(department.Description, dept2.Description) AS description,
                    ROW_NUMBER() OVER (
                        PARTITION BY COALESCE(invVend.ItemNum, inv2.ItemNum,
                                              newInvVend.Vendor_Part_Num)
                        ORDER BY CASE WHEN invVend.ItemNum IS NOT NULL THEN 0 ELSE 1 END,
                                 newInvVend.ModifiedDate DESC,
                                 newInvVend.Vendor_Part_Num
                    ) AS item_rank
                FROM (
                    SELECT *
                    FROM Inventory_Vendors
                    WHERE Store_ID = :storeId
                ) invVend
                FULL OUTER JOIN Inventory_Vendors_v1 newInvVend
                    ON invVend.Vendor_Part_Num = newInvVend.Vendor_Part_Num
                   AND invVend.Vendor_Number    = newInvVend.Vendor_Number
                LEFT JOIN Vendors vendor
                    ON vendor.Vendor_Number = COALESCE(invVend.Vendor_Number, newInvVend.Vendor_Number)
                LEFT JOIN Inventory inventory
                    ON inventory.ItemNum = invVend.ItemNum
                   AND inventory.Store_ID = invVend.Store_ID
                LEFT JOIN Inventory inv2
                    ON invVend.ItemNum IS NULL
                   AND inv2.Vendor_Part_Num = newInvVend.Vendor_Part_Num
                   AND inv2.Store_ID = '9999'
                LEFT JOIN Departments department
                    ON department.Dept_ID = inventory.Dept_ID
                LEFT JOIN Departments dept2
                    ON dept2.Dept_ID = inv2.Dept_ID
                WHERE COALESCE(invVend.Vendor_Number, newInvVend.Vendor_Number) = :vendorNumber
                  AND EXISTS (
                      SELECT 1
                      FROM Inventory_Vendors storeMapping
                      WHERE storeMapping.Vendor_Number = :vendorNumber
                        AND storeMapping.Store_ID = :storeId
                  )
            )
            SELECT vendorName, itemNum, storeId, vendorNumber, costPer,
                   caseCost, numPerVenCase, vendorPartNum, itemName, category,
                   inStock, deptId, description
            FROM consolidated
            WHERE item_rank = 1
            """,
		nativeQuery = true
	)
	List<VendorInventoryProjection> findConsolidatedItemsByVendorNumber( @Param("vendorNumber") String vendorNumber,
			@Param("storeId") String storeId
	);

}
